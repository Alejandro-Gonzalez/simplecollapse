"use strict";

$(document).ready(function () {
  $(".collapse").collapse();
});